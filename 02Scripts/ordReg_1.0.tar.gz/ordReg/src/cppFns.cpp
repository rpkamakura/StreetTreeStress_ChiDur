#include <RcppArmadillo.h>
#include <Rmath.h>
#include <RcppArmadilloExtensions/sample.h>

using namespace Rcpp;
using namespace arma;


// [[Rcpp::depends(RcppArmadillo)]]
// [[Rcpp::export]]
double tnormRcpp(double lo, double hi, double mu, double sig){
  
  double q1, q2, z;
  
  q1 = Rf_pnorm5(lo,mu,sig,1,0);
  q2 = Rf_pnorm5(hi,mu,sig,1,0);
  z = Rf_runif(q1,q2);
  z = Rf_qnorm5(z, mu, sig, 1, 0);
  
  if(z > hi){
    z = lo;
  }
  
  if(z < lo){
    z = hi;
  }
  
  return(z);
}


// [[Rcpp::depends(RcppArmadillo)]]
// [[Rcpp::export]]
arma::mat betaRcpp(int n, arma::mat X, arma::vec y, 
                   double sigma,  arma::mat AI){
  int ncols = AI.n_cols;
  
  arma::mat XX = X.t() * X;
  arma::colvec v = X.t()/sigma * y;
  arma::mat IXX = XX/sigma + AI;
  arma::mat V = inv_sympd(IXX);
  arma::colvec mu = V * v;
  
  arma::mat z = randn(n, ncols);
  
  return arma::repmat(mu, 1, n).t() + z * chol(V);
}

// [[Rcpp::depends(RcppArmadillo)]]
// [[Rcpp::export]]
arma::mat randEffectRcpp(arma::uvec gindex, arma::uvec groups,
                         arma::mat X, arma::colvec y,
                         double sigma, arma::mat AI) {
  
  int ngroup = groups.n_elem;
  int q = X.n_cols;
  mat Z(ngroup,q); Z.fill(0);
  
  for(int j = 0; j < ngroup; j++){
    
    uvec ws = find(gindex == groups(j));
    int nj = ws.size();
    if(nj < 3) continue;
    
    mat tempW = X.rows(ws);
    vec tempY = y.elem(ws);
    
    Z.row(j) = betaRcpp(1, tempW, tempY, sigma, AI);
  }
  return Z;
}

// [[Rcpp::depends(RcppArmadillo)]]
// [[Rcpp::export]]
arma::mat solveRcpp(arma::mat A) {
  arma::mat AA(A);
  arma::mat Ainv = arma::inv_sympd(AA);
  return Ainv;
}

// [[Rcpp::depends(RcppArmadillo)]]
// [[Rcpp::export]]
arma::mat rmvnormRcpp(int n, arma::vec mu, arma::mat sigma) {
  int ncols = sigma.n_cols;
  bool success = false;
  arma::mat S = sigma;
  
  arma::mat Y = randn(n, ncols);
  
  success = chol(S, sigma);
  if(success == false){
    sigma += eye(ncols,ncols) * 1e-5;
  }
  success = chol(S, sigma);
  if(success == false){
  //    throw std::range_error("sigma not positive definite");
      return arma::repmat(mu*0, 1, n).t();
  }
  return arma::repmat(mu, 1, n).t() + Y * chol(sigma);
}

