
# TOF
# functions for ordinal probit random effects: opre


toConsole <- function( message, object = NULL, verbose = T ){
  
  if( !verbose )return()
  
  m <- paste('\n', message, '\n', sep='' )
  if( !is.null(object) )m <- paste('\n', message, ':\n', sep='' )
  cat(m)
  
  if( is.null(object) )return()
  print( object )
  cat('\n\n')
}

print.or <- function(x, ...) summary.or(x)

summary.or <- function(object,...){ 
  
  toConsole( 'Summary of fitted model', object$fit )
  
  if( 'byClass' %in% names( object ) )toConsole( 'By response', object$byClass )
  
  toConsole( 'Coefficients', object$parameters$beta )
  
  toConsole( 'Partition estimates', object$parameters$partition )
  
  randName <- object$inputs$randName
  if( !is.null( randName ) ){
    RE <- TRUE
    randVars <- object$inputs$randVars
    toConsole( 'Random effects mean estimates', object$parameters$randMu )
    toConsole( 'Random effects standard errors', object$parameters$randSe )
    toConsole( 'Random effects covariance over groups', object$parameters$randVarMu )
  }
}

chain2table <- function( x, burnin = 1, sigfig = 4 ){
  
  if( is.list(x) ){
    z <- numeric(0)
    ng <- nrow( x[[1]] )
    for( k in 1:length( x ) )z <- rbind( z, x[[k]][drop=F, burnin:ng, ])
    x <- z
    rm( z )
  }
  
  mu <- colMeans(x)  
  SE <- apply(x,2,sd)
  CI <- apply(x,2,quantile,c(.025,.975))
  splus <- rep('', length=length(SE))
  splus[CI[1,] > 0 | CI[2,] < 0] <- '*'
  
  tab <- cbind( mu, SE, t(CI))
  tab <- signif(tab, sigfig)
  colnames(tab) <- c('Estimate','SE','CI_025','CI_975')
  tab <- as.data.frame(tab)
  tab$sig95 <- splus
  attr(tab, 'note') <- '* indicates that zero is outside the 95% CI'
  
  tab
}


orChainPlot <- function( x, refVals = NULL ){
  
  x1 <- x
  nchain <- 1
  if( is.list(x) ){
    nchain <- length(x)
    x1 <- x[[1]]
  }
  
  if( nchain == 1 ){  # one plot
    
    plot( NA, xlim = c(1, nrow(x1) ), ylim = range(x1), ylab = 'Parameter value' )
    for( j in 1:ncol(x1) ){
      lines( x1[,j], type = 'l', col = j )
      if( !is.null(refVals) )abline( h = refVals[j], lty = 2, col = j )
    }
  }else{        # one plot per variable
    
    wc <- which( apply( x1, 2, var ) > 0 )
    ymat <- matrix( 0, ncol(x1), 2 )
    
    for( j in wc){
      
      rr <- numeric(0)
      for( k in 1:length(x) ){
        rr <- c( rr, range( x[[k]][,j] ) )
      }
      ymat[j,] <- range(rr)
    }
    
    mfrow <- .getPlotLayout( length( wc ) )
    par( mfrow = mfrow$mfrow, bty = 'n', mar = c( 2, 4, 1, 1 ), oma = c( 2, 3, 1, 1 ) ) 
    
    for( j in wc){
      plot( x1[,j], xlim = c(1, nrow(x1) ), ylim = ymat[j,], ylab = colnames(x1)[j],
            type = 'l')
      for( k in 2:length(x) ){
        lines( x[[k]][, j], col = k )
      }
      if( !is.null(refVals) ){
        abline( h = refVals[j], lwd = 2, col = 'white' )
        abline( h = refVals[j], lwd = 2, col = 'grey', lty = 2 )
      }
    }
  }
}

orSim <- function( n = 1000, Q = 3, K = 6, S = NULL, ngroup = 0, R = 0 ){
  
  # ngroup - no. random groups; if ngroup == 0, then no random effects
  # R      - no. random effects <= Q
  # S      - number of responses (for multivariate)
  
  if( !is.null( S ) ){
    
    if( ngroup > 0 | R > 1 )stop( 'only random intercepts (R = 1) for multivariate responses (S > 1)' )
    
    f <- gjamSimData( n = n, S = S, Q = Q, typeNames = 'OC' )
    
    parameters <- list( beta = f$trueValues$beta, partition = f$trueValues$cuts, 
                        sigma = f$trueValues$corSpec )
    
    return( list( formula = f$formula, data = f$xdata, ydata = f$y + 1, parameters = parameters ) )
  }
  
  RE <- FALSE
  x <- matrix( rnorm( n*Q, 0, 4 ), n, Q )
  x[,1] <- 1
  beta  <- matrix( rnorm( Q, 0, 4 ) )
  colnames(x) <- rownames(beta) <- c( '(Intercept)', paste('x', 2:Q, sep='') )
  re <- 0
  
  form <- as.formula( paste( 'y ~ ', paste0( colnames(x)[-1], collapse = ' + ' ) ) )
  
  if( ngroup > 0 ){
    RE     <- TRUE
    group  <- sample( letters[1:ngroup], n, replace = T )
    groups <- sort( unique(group) )
    igroup <- match( group, groups )
    rnames <- colnames(x)[1:R]
    A <- crossprod( x[drop=F, 1:40,1:R] )/100
    a <- .rMVN( ngroup, 0, A ) 
    A <- var(a)
    colnames(a) <- rownames(A) <- colnames(A) <- rnames
    amat <- a[drop=F, igroup,]
    re   <- rowSums( x[,rnames]*amat )    # random effects
  }
  w  <- rnorm( n, x%*%beta + re, 1 )  # latent variable
  
  p <- quantile( w, seq( 0, .9, length = K+1 ) )
  y <- findInterval( w, p )           # ordinal counts
  
  first <- mean( c( max(w[y == 1]), min(w[y == 2]) ) )
  
  w <- w - first  # set first partition to zero
  p <- p - first
  
  p <- p[-1]
  p[1] <- 0
  
  beta  <- solve( crossprod(x) )%*%crossprod(x, w - re)  # translate beta
  
  parameters <- list( beta = beta, partition = p, sigma = 1 )
  
  v <- x[,-1]
  data <- data.frame( y, v )
  
  if( RE ){
    a <- a
    A <- var( a )
    parameters <- c( parameters, list( randVars = rnames, randEff = a, randVar = A ) )
    data$group <- group
  }
  list( formula = form, data = data, parameters = parameters )
}

.rwish <- function( df, SS ){
  z  <- matrix( rnorm( df*nrow( SS ) ), df, nrow( SS ) )%*%chol( SS )
  crossprod( z )
}

.riwish <- function( df, S ){
  solveRcpp( .rwish( df, solveRcpp( S ) ) )
}



columnSplit <- function(vec, sep='_', ASFACTOR = F, ASNUMERIC=F,
                        LASTONLY=F){
  
  vec <- as.character(vec)
  nc  <- length( strsplit(vec[1], sep)[[1]] )
  mat <- matrix( unlist( strsplit(vec, sep) ), ncol=nc, byrow=T )
  if(LASTONLY & ncol(mat) > 2){
    rnn <- mat[,1]
    for(k in 2:(ncol(mat)-1)){
      rnn <- columnPaste(rnn,mat[,k])
    }
    mat <- cbind(rnn,mat[,ncol(mat)])
  }
  if(ASNUMERIC){
    mat <- matrix( as.numeric(mat), ncol=nc )
  }
  if(ASFACTOR){
    mat <- data.frame(mat)
  }
  mat
}


.replaceString <- function(xx,now='_',new=' '){  #replace now string in vector with new
  
  ww <- grep(now,xx,fixed=T)
  if(length(ww) == 0)return(xx)
  
  for(k in ww){
    s  <- unlist( strsplit(xx[k],now,fixed=T) )
    ss <- s[1]
    if(length(s) == 1)ss <- paste( ss,new,sep='')
    if(length(s) > 1)for(kk in 2:length(s)) ss <- paste( ss,s[kk],sep=new)
    xx[k] <- ss
  }
  xx
}


.cleanNames <- function(xx){
  
  xx <- .replaceString(xx,'-','')
  xx <- .replaceString(xx,'_','')
  xx <- .replaceString(xx,' ','')
  xx <- .replaceString(xx,"'",'')
  
  xx
}

or <- function( formula, data, ydata = NULL, randName = NULL, randVars = NULL, burnin = 500,
                  ng = 5000, nchain = 2 ){
  
  # ordinal probit with random effects
  # y are in ordinal classes from 1 to K
  
  RE <- FALSE
  
  if( missing(data) ) data <- environment(formula)
  
  tmp <- model.frame( formula, data )
  x   <- model.matrix( formula, tmp )
  y   <- tmp$y
  Q   <- ncol(x)
  n   <- length(y)
  xnames <- colnames(x)
  
  if( !is.null( randName ) ){
    
    if( is.null( randVars ) )stop( 'need randVars specifying variables in formula to treat as random' )
    if( !all( randVars %in% xnames ) ){
      stop( 'randVars must be a subset of variables in formula' )
    }
    if( randName %in% attr( terms(formula), 'term.labels' ) ){
      st <- paste( 'randName =', randName,  '(random groups) cannot also be in formula (fixed effects)' )
      stop( st )
    }
    
    RE <- TRUE
    group  <- data[, randName ]
    groups <- sort( unique(group) )
    ngroup <- length(groups)
    igroup <- match( group, groups )
    R <- length(randVars)
  }
  
  if( !is.null( ydata ) ){
    
    miny <- apply( ydata, 2, min, na.rm = T )
    w0   <- which( miny != 1 )
    if( length(w0) > 0 )stop( 'classes need labels 1, 2, ...' )
    
    ydata  <- as.matrix( ydata )
    colnames( ydata ) <- .cleanNames( colnames(ydata) )
    S      <- ncol( ydata )
    ynames <- colnames( ydata )
    n      <- nrow( ydata )
    K   <- apply( ydata, 2, max, na.rm = T ) - 1
    
    modelList <- list( ng = ng, burnin = burnin, typeNames = 'OC' )
    
    plist <- vector( 'list', nchain )
    blist <- slist <- plist
    if( RE ){
      alist <- plist
      modelList$random <- randName
    }
    
    yhat <- yvar <- ydata*0
    
    if( RE ){
      rgMu <- rgVr <- matrix(0, S, ngroup, dimnames = list( ynames, groups ) )
      rvMu <- rvVr <- matrix(0, S, S, dimnames = list( ynames, ynames ) )
    }
    
    for( k in 1:nchain) {
      
      if( nchain > 1 )cat( paste('\nchain ', k, ':\n', sep='') )
      
      out <- gjam( formula, xdata = data, ydata = ydata - 1, modelList = modelList )
      
      plist[[k]] <- out$chains$cgibbs
      blist[[k]] <- out$chains$bgibbsUn
      slist[[k]] <- out$chains$sgibbs
      
      yhat <- yhat + out$prediction$ypredMu + 1
      yvar <- yvar + out$prediction$ypredSd^2
      
      if( RE ){
        rgMu <- rgMu + out$parameters$randByGroupMu
        rgVr <- rgVr + out$parameters$randByGroupSe^2
        rvMu <- rvMu + out$parameters$randGroupVarMu
        rvVr <- rvVr + out$parameters$randGroupVarSe^2
      }
    }
    
    yhat <- yhat/nchain
    yse  <- sqrt( yvar/nchain )
    
    if( RE ){
      randMu    <- rgMu/nchain
      randSe    <- sqrt( rgVr/nchain )
      randVarMu <- rvMu/nchain
      randVarMu <- ( randVarMu + t( randVarMu ) )/2
      randVarSe <- sqrt( rvVr/nchain )
    }
    
    bg   <- chain2table( blist, burnin = burnin, sigfig = 4 )
    sg   <- chain2table( slist, burnin = burnin, sigfig = 4 )
    part <- chain2table( plist, burnin = burnin, sigfig = 4 )
    
    part <- part[ is.finite( part[,1] ), ]
    tmp  <- columnSplit( rownames(part), '_C-' )
    part <- data.frame( y = tmp[,1], segment = as.numeric( tmp[,2] ), part )
    part <- part[, !colnames(part) == 'sig95' ]
    
    part[ , c( 'Estimate', 'SE', 'CI_025', 'CI_975' ) ] <- 
      part[ , c( 'Estimate', 'SE', 'CI_025', 'CI_975' ) ] + 1
    
    rr <- data.frame( y = rep( .cleanNames( ynames ), each = 2 ), segment = rep( 1:2, S ), 
                Estimate = rep( c(-Inf, 0), S), SE = 0 )
    rr$CI_025 <- rr$CI_975 <- rr$Estimate
    part <- rbind( part, rr )
  
    partition <- part[ order( part$y, part$segment ), ]
    rownames(partition) <- NULL
    
    ydat <- ydata
    colnames( ydat ) <- .cleanNames( colnames(ydat) )
    ytab <- unlist( apply( ydat, 2, table ) )
    pij  <- paste( partition$y, partition$segment, sep = '.' )
    mm   <- match( names(ytab), .cleanNames( pij ) )
    wf   <- which( is.finite( mm ) )
    
    partition$n <- 0
    partition$n[mm[wf]] <- ytab[wf]
    
    RMSPE <- sqrt(  colMeans( (ydat - yhat)^2, na.rm = T ) )
    ymu   <- sweep( ydat, 2, colMeans(ydat, na.rm=T), '-' )
    r2    <- 1 - colSums( (yhat - ydat)^2,  na.rm = T )/
                 colSums( ymu^2, na.rm = T  )
    
    DIC   <- out$fit$DIC
    
    byClass <- data.frame( ordinal_classes = K, r2 = round(r2, 3), RMSPE = signif(RMSPE, 3) )
    
    ftab <- data.frame( n = nrow(data), predictors = Q, DIC = DIC )
    if( RE ){
      ftab$ngroup  <- ngroup
      ftab$randVars <- R
    } 
    
    colnames(yhat) <- paste( colnames(yhat), 'yhat', sep = '_' )
    colnames(yse) <- paste( colnames(yse), 'SE', sep = '_' )
    
    inputs     <- list( data = data, formula = formula, nchain = nchain, ng = ng, burnin = burnin )
    parameters <- list( beta = bg, partition = partition, sigma = sg  )
    chains     <- list( bgibbs = blist, pgibbs = plist, sgibbs = slist )
    prediction <- cbind( yhat, yse )
    
    if( RE ){
      inputs     <- c( inputs, list( randName = randName, randVars = randVars ) )
      parameters <- c( parameters, list( randMu = randMu, randSe = randSe, 
                                         randVarMu = randVarMu, randVarSe = randVarSe ) )
    }
    
    out <- list( inputs = inputs, parameters = parameters, prediction = prediction,
                 chains = chains, fit = ftab, byClass = byClass )
    class(out) <- "or"
    return( out )
  }
  
  
  # partition
  if( !min(y) == 1 )stop( 'ordinal classes must start at 1' )
  K   <- max(y) - 1
  k1  <- 2:K
  k2  <- 3:(K+1)
  pg  <- 0:(K - 1 )
  wlo <- c(-Inf, pg )
  whi <- c( pg, Inf )
  
  # prior parameter values
  s1 <- s2 <- 10
  XX <- crossprod(x)
  priorIVB <- solve( diag(1000, Q) )
  priorB   <- matrix( 0, Q, dimnames = list( xnames, NULL ) )
  s1 <- s2 <- 10
  
  # initialize
  wlo <- c(-Inf, pg )
  whi <- c( pg, Inf )

  if( RE ){
    priorIVA <- diag(R)/10
    dimnames( priorIVA ) <- list( randVars, randVars )
    priorA <- solveRcpp( priorIVA )
    arand  <- matrix( 0, ngroup, R, dimnames = list( groups, randVars) )
    Ag     <- solveRcpp( priorIVA )
    a1 <- a2 <- arand*0
  }
  w  <- .tnorm( n, lo = wlo[y], hi = whi[y], y - 1, 1 )
  re <- w*0
  
  plist <- vector( 'list', nchain )
  blist <- slist <- plist
  if( RE )alist <- plist
  pred <- pred2 <- w*0
  loglik <- 0
  
  for( k in 1:nchain) {
    
    if( nchain > 1 )cat( paste('\nchain ', k, ':\n', sep='') )
    
    pgibbs <- matrix(NA, ng, K)
    bgibbs <- matrix(NA, ng, Q, dimnames = list(NULL, xnames))
    sgibbs <- matrix(NA, ng, 1)
    if( RE )Agibbs <- matrix(NA, ng, R*R )
    
    w  <- .tnorm( n, lo = wlo[y], hi = whi[y], y - 1, 1 )
    re <- w*0
    sg <- 1/rgamma(1, s1, s2 )
    
    pbar <- txtProgressBar( min=1, max=ng, style=1)
    
    for( g in 1:ng ){
      
   #  bg <- updateBeta(x, w - re, sigma = sg, priorIVB, priorB, XX = XX )
      bg <- t( betaRcpp(1, x, w - re, sg, priorIVB) )
      
      if( RE ){
     #  arand <- updateRE( w, x, bg, sg, Ag, arand, randVars, igroup, ngroup ) # if not Rcpp
        arand <- randEffectRcpp( gindex = igroup, groups = 1:ngroup, 
                                 x[drop=F,,randVars], w - x%*%bg, sg, solveRcpp( Ag ) )
        Ag    <- .riwish(R + ngroup + 1, priorA + crossprod( arand )  ) 
        amat  <- arand[drop = F, igroup,]
        re    <- rowSums(x[,randVars]*amat)
      }
      
      sg   <- updateSigma( w, x%*%bg + re, s1, s2)
      ag   <- bg/sqrt(sg)                       
      if( RE )rmat <- amat/sqrt(sg)
      
      # intervals for updating cutpoints
      pmin <- tapply( w, y, min )
      pmax <- tapply( w, y, max )
      
      pg[-1] <- runif( K-1, pmax[k1], pmin[k2] )
      pg <- pg/sqrt(sg)
      
      wlo <- c(-Inf, pg )
      whi <- c( pg, Inf )
      mu  <- x%*%ag 
      if( RE ) mu <- mu + rowSums( x[,randVars]*rmat )
      w   <- .tnorm( n, lo = wlo[y], hi = whi[y], mu, 1 )
      
      if( g >= burnin & k == 1 ){ # prediction
        py    <- findInterval( rnorm( n, mu, 1 ), c( -Inf, pg, Inf ) )
        pred  <- pred + py
        pred2 <- pred2 + py^2
        
        if( RE ){
          a1 <- a1 + arand
          a2 <- a2 + arand^2
        }
        
        pk <- c( -Inf, pg, Inf )
        loglik <- loglik + sum( log( pnorm( pk[y+1] - mu ) - pnorm( pk[y] - mu ) ) )
      }
      
      pgibbs[g, ] <- pg
 #     bgibbs[g, ] <- bg
      bgibbs[g, ] <- ag
      
      if( RE )Agibbs[g, ] <- as.vector( Ag )
      
      setTxtProgressBar( pbar, g )
    }
    
    plist[[k]] <- pgibbs
    blist[[k]] <- bgibbs
    slist[[k]] <- sgibbs
    if( RE )alist[[k]] <- Agibbs
  }
  
  ny    <- (ng - burnin + 1)#*nchain
  yhat  <- pred/ny
  y2    <- pred2/ny
  dy    <- ny/(ny - 1)*( y2 - yhat^2 )
  yse   <- sqrt( dy )
  
  RMSPE <- sqrt(  mean( (y - yhat)^2 ) )
  r2    <- 1 - sum( (yhat - y)^2 )/sum( (y - mean(y))^2 )
  
  bg         <- chain2table( blist, burnin = burnin, sigfig = 4 )
  partition  <- chain2table( plist, burnin = burnin, sigfig = 4 )
  partition  <- partition[ ,!colnames(partition) == 'sig95' ]
  partition  <- rbind( partition[1,], partition )
  partition[1, c('Estimate', 'CI_025', 'CI_975')] <- -Inf
  segment <- c(1:(K+1) )
  partition <- cbind( segment, partition )
  ytab <- table( y ) 
  mm   <- match( names(ytab), as.character(segment) )
  partition$n <- 0
  partition$n[mm] <- ytab
  
  inputs     <- list( data = data, formula = formula, nchain = nchain, ng = ng, burnin = burnin )
  parameters <- list( beta = bg, partition = partition  )
  chains     <- list( bgibbs = blist, pgibbs = plist, sgibbs = slist )
  prediction <- cbind( yhat, yse )
  
  mu <- x%*%matrix(bg[,1], ncol = 1 )
  
  if( RE ){
    amu <- a1/ny 
    aa  <- a2/ny
    da  <- ny/(ny - 1)*( aa - amu^2 )
    ase <- sqrt( da )
    A          <- chain2table( alist, burnin = 100, sigfig = 4 )
    inputs     <- c( inputs, list( randName = randName, randVars = randVars ) )
    parameters <- c( parameters, list( randMu = amu, randSe = ase, randVarMu = A ) )
    chains     <- c( chains, list( Agibbs = alist ) )
    amat  <- amu[drop = F, igroup,]
    mu <- mu + rowSums( x[drop=F, , randVars]*amat )
  }
  
  pk   <- c( partition[,'Estimate'], Inf )
  llMu <- sum( log( pnorm( pk[y+1] - mu ) - pnorm( pk[y] - mu ) ) )
  
  meanDev <- -2*loglik/ny
  devMean <- -2*llMu
  pd      <- meanDev - devMean
  DIC     <- devMean + 2*pd
  
  ftab <- data.frame( n = nrow(x), predictors = Q, ordinal_classes = K, 
                      DIC = round( DIC, 1), r2 = round(r2, 3), RMSPE = signif(RMSPE, 3) )
  if( RE ){
    ftab$ngroup  <- ngroup
    ftab$randVars <- R
  }
  
  out <- list( inputs = inputs, parameters = parameters, prediction = prediction,
               chains = chains, fit = ftab )
  class(out) <- "or"
  out
} 
 
updateRE <- function( w, x, bg, sg, Ag, arand, rnames, igroup, ngroup ){
  
  IAg <- solve( Ag )
  
  for( i in 1:ngroup){
    wi <- which( igroup == i )
    v <- crossprod(w[wi] - x[ wi, ]%*%bg, x[wi,rnames] )/sg 
    V <- solve( crossprod( x[ wi ,rnames ] )/sg + IAg )
    arand[i,] <- .rMVN(1, v%*%V, V )
  }
  arand
}

.tnorm <- function(n,lo,hi,mu,sig){   
  
  #normal truncated lo and hi
  
  tiny <- 10e-6
  
  if(length(lo) == 1 & length(mu) > 1)lo <- rep(lo,length(mu))
  if(length(hi) == 1 & length(mu) > 1)hi <- rep(hi,length(mu))
  
  q1 <- pnorm(lo,mu,sig)
  q2 <- pnorm(hi,mu,sig) 
  
  z <- runif(n,q1,q2)
  z <- qnorm(z,mu,sig)
  
  z[z == Inf]  <- lo[z == Inf] + tiny
  z[z == -Inf] <- hi[z == -Inf] - tiny
  z
}

updateSigma <- function(y, mu, s1, s2){ # random value for residual variance
  n  <- length(y)
  u1 <- s1 + n/2
  u2 <- s2 + 0.5*crossprod(y - mu)
  1/rgamma(1,u1,u2)                          
}

.rMVN <- function (nn, mu, sigma){
  
  # nn - no. samples from one mu vector or nrow(mu) for matrix
  
  if(!is.matrix(mu)) mu <- matrix(mu,1)
  if(length(mu) == 1)mu <- matrix(mu,1,nrow(sigma))
  if(ncol(mu) == 1)  mu <- t(mu)
  
  m <- ncol(sigma)
  
  if(ncol(mu) != m)stop('dimension mismatch mu, sigma')
  
  if(nn > 1 & nrow(mu) == 1)mu <- matrix(mu,nn,m,byrow=T)
  
  if(nn != nrow(mu))stop('sample size does not match mu')
  
  testv <- try(svd(sigma),T)
  
  if( inherits(testv,'try-error') ){
    ev <- eigen(sigma, symmetric = T)
    testv <- t(ev$vectors %*% (t(ev$vectors) * sqrt(ev$values)))
  } else {
    testv <- t(testv$v %*% (t(testv$u) * sqrt(testv$d)))
  }
  
  p <- matrix(rnorm(nn * m), nn) %*% testv
  p + mu
}

updateBeta <- function(x, y, sigma, priorIVB, priorB, 
                       XX=NULL){  # random vector of coefficients
  
  if(is.null(XX))XX <- crossprod(x)
  
  V  <- solve( XX/sigma + priorIVB ) 
  v  <- crossprod(x,y)/sigma + priorIVB%*%priorB
  t( .rMVN(1,t(V%*%v),V) )                     
}

.getPlotLayout <- function( np, WIDE = TRUE ){
  
  # np - no. plots
  
  if( np == 1 )return( list( mfrow = c( 1, 1 ), left = 1, bottom = c( 1, 2 ) ) )
  if( np == 2 ){
    if( WIDE )return( list( mfrow = c( 1, 2 ), left = 1, bottom = c( 1, 2 ) ) )
    return( list( mfrow = c( 2, 1 ), left = c( 1, 2 ), bottom = 2 ) )
  }
  
  if( np == 3 ){
    if( WIDE )return( list( mfrow = c( 1, 3 ), left = 1, bottom = c( 1:3 ) ) )
    return( list( mfrow = c( 3, 1 ), left = 1:3, bottom = 3 ) )
  }
  if( np <= 4 )return( list( mfrow = c( 2, 2 ), left = c( 1, 3 ), bottom = c( 3:4 ) ) )
  if( np <= 6 ){
    if( WIDE )return( list( mfrow = c( 2, 3 ), left = c( 1, 4 ), bottom = c( 4:6 ) ) )
    return( list( mfrow = c( 3, 2 ), left = c( 1, 3, 5 ), bottom = 5:6 ) )
  }
  if( np <= 9 )return( list( mfrow = c( 3, 3 ), left = c( 1, 4, 7 ), bottom = c( 7:9 ) ) )
  if( np <= 12 ){
    if( WIDE )return( list( mfrow = c( 3, 4 ), left = c( 1, 5, 9 ), bottom = c( 9:12 ) ) )
    return( list( mfrow = c( 4, 3 ), left = c( 1, 4, 7, 10 ), bottom = 10:12 ) )
  }
  if( np <= 16 )return( list( mfrow = c( 4, 4 ), left = c( 1, 5, 9, 13 ), 
                              bottom = c( 13:16 ) ) )
  if( np <= 20 ){
    if( WIDE )return( list( mfrow = c( 4, 5 ), left = c( 1, 6, 11, 15 ), 
                            bottom = c( 15:20 ) ) )
    return( list( mfrow = c( 5, 4 ), left = c( 1, 5, 9, 13 ), bottom = 17:20 ) )
  }
  if( np <= 25 )return( list( mfrow = c( 5, 5 ), left = c( 1, 6, 11, 15, 20 ), 
                              bottom = c( 20:25 ) ) )
  if( np <= 25 ){
    if( WIDE )return( list( mfrow = c( 5, 6 ), left = c( 1, 6, 11, 15, 20, 25 ), 
                            bottom = c( 25:30 ) ) )
    return( list( mfrow = c( 6, 5 ), left = c( 1, 6, 11, 16, 21, 26 ), bottom = 26:30 ) )
  }
  if( np <= 36 ){
    return( list( mfrow = c( 6, 6 ), left = c( 1, 7, 13, 19, 25, 31 ), bottom = c( 31:36 ) ) )
  }
  return( list( mfrow = c( 7, 6 ), left = c( 1, 7, 13, 19, 25, 31, 37 ), bottom = c( 37:42 ) ) )
}


